<!--
Taco Blogs V 3.0
Login Page V 1.0
Programmers Roland, Kevin, Josh, Chuong
9/7/2018
Description:
     Anouncment stating that the registration resulted in an error
Resources: PHP and MySQL web Development, www.w3schools.com
--><?php
echo 'register error. Username is exists. Try different username';
?>
<html>
Try again
<a href="index.html">Register</a>
</html>
