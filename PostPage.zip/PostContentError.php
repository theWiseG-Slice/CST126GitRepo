<!--
Taco Blogs V 3.0
Login Page V 1.0
Programmers Roland, Kevin, Josh, Chuong
10/7/2018
Description:
     Anouncment stating that the post had an error
Resources: PHP and MySQL web Development
--><?php
/**
 * Created by PhpStorm.
 * User: Chuong
 * Date: 10/4/2018
 * Time: 1:26 PM
 */
echo 'post content error';