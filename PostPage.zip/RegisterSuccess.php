<!--
Taco Blogs V 3.0
Register Success V 1.0
Programmers Roland, Kevin, Josh, Chuong
9/7/2018
Description:
    Anouncemnet stating registration sucessfull
Resources: PHP and MySQL web Development, www.w3schools.com
-->
<?php
echo 'Registeration Successful';
?>
<html>
Login
<a href="Login.html">Login</a>
</html>
