<!--
Taco Blogs V 3.0
Login Page V 1.0
Programmers Roland, Kevin, Josh, Chuong
10/7/2018
Description:
    error message if you are not logged in
Resources: PHP and MySQL web Development
--><?php
/**
 * Created by PhpStorm.
 * User: Chuong
 * Date: 10/6/2018
 * Time: 2:36 PM
 */
echo 'You need to login to add post';
?>
<a href="Login.html">Login</a>