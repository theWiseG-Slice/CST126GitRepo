USE try1;
create table users(
   username varchar(50) NOT NULL,
   pword VARCHAR(100) NOT NULL,
   firstname VARCHAR(50) NOT NULL,
   lastname varchar(50),
   email varchar(100)
);