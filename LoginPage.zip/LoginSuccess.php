<!--
Taco Blogs V 2.0
Login Success Script V 1.0
Programmers Roland, Kevin, Josh, Chuong
9/7/2018
Description:
      After Checking login anounces a sucesful login
Resources: PHP and MySQL web Development, www.w3schools.com
-->
<?php
echo "Login Success";
?>
<html>
Go back
<a href="Login.html">Login</a>
</html>
